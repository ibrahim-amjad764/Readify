# RepoRead — AI README Generator

> Paste any GitHub URL → get a production-grade README.md in seconds.

[![Next.js](https://img.shields.io/badge/Next.js-14-black?logo=next.js)](https://nextjs.org)
[![TypeScript](https://img.shields.io/badge/TypeScript-strict-blue?logo=typescript)](https://typescriptlang.org)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3-06B6D4?logo=tailwindcss)](https://tailwindcss.com)
[![GPT-4o-mini](https://img.shields.io/badge/OpenAI-GPT--4o--mini-412991?logo=openai)](https://openai.com)

---

## ✨ Features

- 🔗 **Paste any public GitHub URL** — automatic owner/repo extraction with full URL validation
- 🤖 **AI-powered analysis** — GPT-4o-mini reads your file tree, `package.json`, topics, and language
- 📄 **9 README sections** — badges, overview, features, tech stack, install, usage, config, contributing, license
- 👁️ **Live markdown preview** — GitHub-flavoured rendering (tables, code blocks, badges)
- 📋 **One-click copy** — paste-ready markdown with clipboard fallback
- 🛡️ **Injection-safe** — repository content never leaks into prompt instructions
- ⚡ **Rate limiting** — per-IP sliding-window (configurable via env)
- 📱 **Responsive** — stacked on mobile, split-pane on desktop

---

## 🛠 Tech Stack

| Technology | Version | Role |
|---|---|---|
| Next.js | 14.x (App Router) | Framework + API routes |
| TypeScript | 5.x (strict) | Type safety |
| Tailwind CSS | 3.x | Styling |
| `@octokit/rest` | 21.x | GitHub API client |
| `openai` | 4.x | OpenAI SDK |
| `react-markdown` | 9.x | Markdown rendering |
| `remark-gfm` | 4.x | GFM tables, strikethrough |
| Jest + Testing Library | 29.x / 16.x | Unit & component tests |

---

## 📦 Installation

```bash
# 1. Clone
git clone https://github.com/your-username/reporead.git
cd reporead

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.local.example .env.local
# → Edit .env.local and add your API keys (see below)

# 4. Run development server
npm run dev
# → Open http://localhost:3000
```

---

## ⚙️ Environment Variables

Copy `.env.local.example` to `.env.local` and fill in:

```env
# Required
OPENAI_API_KEY=sk-...

# Optional (increases GitHub rate limit from 60 → 5000 req/hour)
GITHUB_TOKEN=ghp_...

# Optional (default: 10 requests per minute per IP)
RATE_LIMIT_RPM=10
```

### Getting API Keys

| Key | Where to get it |
|---|---|
| `OPENAI_API_KEY` | [platform.openai.com/api-keys](https://platform.openai.com/api-keys) |
| `GITHUB_TOKEN` | [github.com/settings/tokens](https://github.com/settings/tokens) — scope: `public_repo` |

---

## 🚀 Usage

1. Open the app at `http://localhost:3000`
2. Paste a GitHub URL: `https://github.com/vercel/next.js`
3. Click **Generate** (or press `Enter`)
4. View the rendered preview or switch to the raw Markdown tab
5. Click **Copy** to copy the markdown to your clipboard

---

## 🧪 Testing

```bash
# Run all tests
npm test

# Watch mode
npm run test:watch

# Coverage report
npm test -- --coverage
```

Tests cover:
- URL parsing (valid + invalid inputs, edge cases)
- `GitHubFetchError` construction and error codes
- Rate limiter (allow / block / reset logic)
- `UrlInput` component (validation, keyboard, loading states)
- `CopyButton` component (clipboard, feedback timing)
- API validation layer

---

## 📁 File Structure

```
reporead/
├── app/
│   ├── layout.tsx           # Root layout (fonts, global CSS, ambient bg)
│   ├── page.tsx             # Server component shell
│   ├── globals.css          # CSS variables + markdown styles
│   └── api/generate/
│       └── route.ts         # POST /api/generate (orchestrates GH + OpenAI)
├── components/
│   ├── RepoReadApp.tsx      # Client root — state machine
│   ├── Navbar.tsx           # Static header (Server Component)
│   ├── HeroSection.tsx      # Landing hero
│   ├── UrlInput.tsx         # URL input with validation
│   ├── MarkdownPreview.tsx  # Split tabs: rendered / raw
│   ├── CopyButton.tsx       # Clipboard copy with feedback
│   └── StatusBanner.tsx     # Loading / error states
├── lib/
│   ├── github.ts            # Octokit wrapper + URL parser
│   ├── openai.ts            # GPT-4o-mini prompt + response
│   ├── rate-limit.ts        # In-memory per-IP rate limiter
│   └── types.ts             # Shared API + state types
└── __tests__/
    ├── lib/github.test.ts
    ├── api/generate.test.ts
    └── components/
        ├── UrlInput.test.tsx
        └── CopyButton.test.tsx
```

---

## 🚢 Deployment (Vercel)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

Then in the Vercel dashboard → **Settings → Environment Variables**, add:

- `OPENAI_API_KEY`
- `GITHUB_TOKEN` _(optional)_
- `RATE_LIMIT_RPM` _(optional, default 10)_

The `maxDuration = 30` export in the API route sets the serverless function timeout to 30 seconds.

---

## 💰 Cost Estimate

GPT-4o-mini pricing (as of 2025):

| Metric | Value |
|---|---|
| Input tokens per README | ~1,500 |
| Output tokens per README | ~2,000 |
| Cost per README | ~$0.001 |
| Cost per 1,000 READMEs | ~$1.00 |

---

## 🤝 Contributing

```bash
git checkout -b feat/your-feature
# make changes
npm test
git commit -m "feat: your feature"
git push origin feat/your-feature
# open a Pull Request
```

Please keep PRs focused and add tests for new behaviour.

---

## 📄 License

MIT — see [LICENSE](LICENSE) for details.
